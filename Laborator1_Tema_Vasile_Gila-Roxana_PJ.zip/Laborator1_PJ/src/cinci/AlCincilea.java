package cinci;

import java.io.IOException;
import java.util.Random;

public class AlCincilea {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
	Random rand=new Random(); 
	int n=rand.nextInt(21);
	System.out.println("Numarul generat este: "+n);
	
	int aux=0, f1=1, f2=0;
	Boolean ok=false;
	
	while(ok!=true)
	{
		if(n==f2)
			{
			ok=true;
			System.out.println("Numarul apartine sirului Fibonacci!");
			}
		if(n<f2) break;
		aux=f2;
		f2=f1+f2;
		f1=aux;
	}
	
	if(ok==false) System.out.println("Numarul NU apartine sirului Fibonacci!");
		
	}

}
