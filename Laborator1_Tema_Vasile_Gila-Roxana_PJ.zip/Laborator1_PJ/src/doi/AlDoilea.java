package doi;

import java.io.File;
import java.io.IOException;
import java.io.PrintStream;
import java.util.Scanner;

public class AlDoilea {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		int x,suma = 0,nrElem=0,maxim = 0,minim = 0;
		float mediA = 0;
		Scanner scanner=new Scanner(new File("in.txt"));
		if(scanner.hasNext()!=false)
			{
		x=scanner.nextInt();
		maxim=x;
		minim=x;
		nrElem++;
		suma=x;
			}
		while(scanner.hasNext()!=false)
		{
			x=scanner.nextInt();
			suma+=x;
			nrElem++;
			if(minim>x) minim=x;
			if(maxim<x) maxim=x;
		}
		if(nrElem!=0)  mediA=(float)suma/nrElem;
		
		System.out.println("Suma numerelor este: "+suma);
		System.out.println("Media aritmedica a numerelor este: "+mediA);
		System.out.println("Numarul minim din fisier este: "+minim);
		System.out.println("Numarul maxim din fisier este: "+maxim);
		
		@SuppressWarnings("resource")
		PrintStream afisare=new PrintStream("out.txt");
		afisare.println("Suma numerelor este: "+suma);
		afisare.println("Media aritmedica a numerelor este: "+mediA);
		afisare.println("Numarul minim din fisier este: "+minim);
		afisare.println("Numarul maxim din fisier este: "+maxim);
		
	}

}
