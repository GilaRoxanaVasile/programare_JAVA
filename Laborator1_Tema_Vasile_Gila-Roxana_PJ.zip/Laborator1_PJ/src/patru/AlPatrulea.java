package patru;

import java.io.IOException;
import java.util.Random;

public class AlPatrulea {

	public static void main(String[] args) throws IOException{
		// TODO Auto-generated method stub
		Random rand=new Random();

		int nr1=rand.nextInt(31);
		int nr2=rand.nextInt(31);
		
		System.out.println("Primul numar generat este: "+nr1);
		System.out.println("Al doilea numar generat este: "+nr2);
		
		while(nr2!=0)
		{
			int r=nr1%nr2;
			nr1=nr2;
			nr2=r;
		}
		
		System.out.println("Cmmdc a celor doua numere generate random este: "+nr1);
	}

}
