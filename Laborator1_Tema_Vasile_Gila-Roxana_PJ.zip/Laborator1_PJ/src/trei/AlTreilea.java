package trei;

import java.io.IOException;
import java.util.Scanner;

public class AlTreilea {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		System.out.println("Dati numarul: ");
		@SuppressWarnings("resource")
		Scanner scanner=new Scanner(System.in);
		int n=scanner.nextInt();
		int nr_divizori=0;
		System.out.println("Divizorii numarului dat sunt: ");
		for(int d=1; d*d<=n;d++)
		{
			if(n%d==0)
			{
				nr_divizori++;
				System.out.println(d);
				if(d*d!=n) System.out.println(n/d);
			}
		}
		if(nr_divizori==1) System.out.println("Numarul este prim!");
	}

}
