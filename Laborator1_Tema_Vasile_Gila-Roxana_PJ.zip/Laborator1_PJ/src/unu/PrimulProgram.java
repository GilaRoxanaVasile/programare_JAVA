package unu;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class PrimulProgram {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		int lungime, latime;
		BufferedReader reader=new BufferedReader(new InputStreamReader(System.in));
		
		System.out.print("Dati lungimea: ");
		lungime=Integer.parseInt(reader.readLine());
		System.out.print("Dati latimea: ");
		latime=Integer.parseInt(reader.readLine());
		
		System.out.print("Permietrul dreptunghiului este: ");
		System.out.print(2*(lungime+latime));
		System.out.println();
		System.out.print("Aria dreptunghiului este: ");
		System.out.print(lungime*latime);
	}

}
